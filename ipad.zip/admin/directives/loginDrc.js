'use strict';
app.directive('loginDirective',function(){

	return{
		templateUrl:'./tpl/login.tpl.html'
	}

});